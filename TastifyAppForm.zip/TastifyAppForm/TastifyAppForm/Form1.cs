﻿/*********************************************************************************************
 * Name:        Randell Lee Saddi + Esteban Coral
 * Date:        11|18|2025
 * Class:       80309 - CIS 022
 * Email:       rsaddi1@solano.students.edu
 * Desc:        Main Programming for the Tastify Application, which automatically finds
 *              a device's general real-world location via public IP address and uses that
 *              to search for restaurants matching user-entered food types or names.
 * AI:          Programming Counseling by speaking with VSCode's Github Copilot AI. All code
 *              otherwise is written by the named authors.
 *********************************************************************************************/

using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TastifyAppForm
{
    public partial class Form1 : Form
    {

        private const string AzureMapsKey = "5khuf8R5o6K8BgALf6oi5U2TxIjMx0hFT4xoFu7ruIO5ScBSOOG2JQQJ99BKACYeBjFPWdKJAAAgAZMP2NUL";
        private const string APIVersion = "1.0";

        // Store discovered location
        private string cityState = null;

        public Form1()
        {
            InitializeComponent();
        }

        private void logoLabel_Click(object sender, EventArgs e)
        {

        }

        // Made async so we can discover public IP and resolve it to a city/state using Azure Maps
        private async void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                string ip = await GetPublicIPAddressAsync();
                if (!string.IsNullOrEmpty(ip))
                {
                    var loc = await GetLocationFromIPAsync(ip);
                    if (loc != null)
                    {
                        cityState = loc.Item1;
                        // Optionally use City/State in UI here
                        // e.g. this.Text = $"{this.Text} - {City}, {State}";
                    }
                }
            }
            catch (Exception)
            {
                // swallow - keep UI responsive; errors handled inside helper methods
            }
        }

        public class info
        {
            [JsonProperty("results")]
            public List<Business> Results { get; set; }

            [JsonProperty("resultCount")]
            public int ResultCount { get; set; }
        }

        public class Business
        {
            [JsonProperty("bizId")]
            public string BizId { get; set; }

            [JsonProperty("name")]
            public string Name { get; set; }

            [JsonProperty("alias")]
            public string Alias { get; set; }

            [JsonProperty("categories")]
            public List<string> Categories { get; set; }

            [JsonProperty("phone")]
            public string Phone { get; set; }

            [JsonProperty("website")]
            public string Website { get; set; }

            [JsonProperty("Images")]
            public List<string> Images { get; set; }

            [JsonProperty("rating")]
            public double Rating { get; set; }

            [JsonProperty("reviewCount")]
            public int ReviewCount { get; set; }
        }

        private async Task<string> GetPublicIPAddressAsync()
        {
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // Use a simple public service to get the IP address
                    string ipAddress = (await client.GetStringAsync("https://api.ipify.org")).Trim();

                    // Validate basic IP format
                    if (string.IsNullOrWhiteSpace(ipAddress) || !IPAddress.TryParse(ipAddress, out _))
                    {
                        MessageBox.Show($"Could not get a valid public IP address (value: '{ipAddress}').");
                        return null;
                    }

                    return ipAddress;
                }
                catch (HttpRequestException ex)
                {
                    MessageBox.Show($"Could not get public IP address: {ex.Message}");
                    return null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Unexpected error while getting public IP: {ex.Message}");
                    return null;
                }
            }
        }

        /// <summary>
        /// Uses Azure Maps IP geolocation API to get a general city and state for a public IP address.
        /// Returns Tuple(cityState) or null on failure.
        /// </summary>
        private async Task<Tuple<string>> GetLocationFromIPAsync(string ip)
        {
            if (string.IsNullOrWhiteSpace(ip))
                return null;

            using (HttpClient client = new HttpClient())
            {
                try
                {
                    // First attempt: Azure Maps
                    string url = $"https://atlas.microsoft.com/ip/geolocation/json?api-version={APIVersion}&ip={WebUtility.UrlEncode(ip)}&subscription-key={AzureMapsKey}";
                    var response = await client.GetAsync(url);
                    var body = await response.Content.ReadAsStringAsync();

                    if (response.IsSuccessStatusCode)
                    {
                        try
                        {
                            var j = JObject.Parse(body);

                            // Try common JSON paths with fallbacks
                            var cityToken = j.SelectToken("ipAddress.city.name")
                                            ?? j.SelectToken("city.name")
                                            ?? j.SelectToken("$..city.name");
                            var stateToken = j.SelectToken("ipAddress.countrySubdivision.name")
                                             ?? j.SelectToken("countrySubdivision.name")
                                             ?? j.SelectToken("$..countrySubdivision.name")
                                             ?? j.SelectToken("$..region.name");

                            string city = cityToken?.ToString()?.Trim();
                            string state = stateToken?.ToString()?.Trim();

                            string citystate = string.Join(" ", new[] { city, state }.Where(s => !string.IsNullOrWhiteSpace(s)));

                            if (!string.IsNullOrWhiteSpace(citystate))
                                return Tuple.Create(citystate);

                            // If Azure responded but didn't include city/state, fall through to fallbacks
                        }
                        catch
                        {
                            // parsing failed - fall through to fallbacks
                        }
                    }
                    else
                    {
                        // Azure returned non-success. We'll try fallbacks below. Optionally, you can inspect `response.StatusCode` and `body` for debugging.
                    }

                    // Fallback #1: ipapi.co (HTTPS, no key required)
                    try
                    {
                        string ipapiUrl = $"https://ipapi.co/{WebUtility.UrlEncode(ip)}/json/";
                        var r2 = await client.GetAsync(ipapiUrl);
                        if (r2.IsSuccessStatusCode)
                        {
                            var body2 = await r2.Content.ReadAsStringAsync();
                            var j2 = JObject.Parse(body2);
                            string city2 = j2.SelectToken("city")?.ToString()?.Trim();
                            string region2 = j2.SelectToken("region")?.ToString()?.Trim();
                            string cs2 = string.Join(" ", new[] { city2, region2 }.Where(s => !string.IsNullOrWhiteSpace(s)));
                            if (!string.IsNullOrWhiteSpace(cs2))
                                return Tuple.Create(cs2);
                        }
                    }
                    catch
                    {
                        // ignore and try next fallback
                    }

                    // Fallback #2: ip-api.com (http, returns regionName)
                    try
                    {
                        string ipapi2 = $"http://ip-api.com/json/{WebUtility.UrlEncode(ip)}?fields=city,regionName,status,message";
                        var r3 = await client.GetAsync(ipapi2);
                        if (r3.IsSuccessStatusCode)
                        {
                            var body3 = await r3.Content.ReadAsStringAsync();
                            var j3 = JObject.Parse(body3);
                            if (j3.SelectToken("status")?.ToString() == "success")
                            {
                                string city3 = j3.SelectToken("city")?.ToString()?.Trim();
                                string region3 = j3.SelectToken("regionName")?.ToString()?.Trim();
                                string cs3 = string.Join(" ", new[] { city3, region3 }.Where(s => !string.IsNullOrWhiteSpace(s)));
                                if (!string.IsNullOrWhiteSpace(cs3))
                                    return Tuple.Create(cs3);
                            }
                        }
                    }
                    catch
                    {
                        // ignore
                    }

                    // All attempts failed
                    MessageBox.Show("Could not resolve IP location from Azure Maps or fallback services. Check internet connection and API key.");
                    return null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Could not resolve IP location: {ex.Message}");
                    return null;
                }
            }
        }

        private Panel CreateReviewCard(Form1.Business biz)
        {
            //makes cards for the businesses
            Panel card = new Panel();
            card.Width = 700;
            card.Height = 180;
            card.Margin = new Padding(10);
            card.BackColor = Color.White;
            card.BorderStyle = BorderStyle.FixedSingle;


            FlowLayoutPanel textPanel = new FlowLayoutPanel();
            textPanel.FlowDirection = FlowDirection.TopDown;
            textPanel.WrapContents = false;
            textPanel.Dock = DockStyle.Left;
            textPanel.Width = 200;
            textPanel.AutoSize = true;
            textPanel.AutoSizeMode = AutoSizeMode.GrowAndShrink;
            textPanel.Padding = new Padding(10);


            Label lblName = new Label();
            lblName.Text = biz.Name;
            lblName.Font = new Font("Arial", 11, FontStyle.Bold);
            lblName.MaximumSize = new Size(180, 0);
            lblName.AutoSize = true;

            Label lblRating = new Label();
            lblRating.Text = $"⭐ {biz.Rating} ({biz.ReviewCount} reviews)";
            lblRating.Font = new Font("Arial", 10);
            lblRating.MaximumSize = new Size(180, 0);
            lblRating.AutoSize = true;

            Label lblCategory = new Label();
            lblCategory.Text = string.Join(", ", biz.Categories);
            lblCategory.Font = new Font("Arial", 9, FontStyle.Italic);
            lblCategory.MaximumSize = new Size(180, 0);
            lblCategory.AutoSize = true;

            Button btnWebsite = new Button();
            btnWebsite.Text = "Visit Website";
            btnWebsite.Location = new Point(10, 100);
            btnWebsite.Click += (s, e) =>
            {
                if (!string.IsNullOrEmpty(biz.Website))
                    System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
                    {
                        FileName = biz.Website,
                        UseShellExecute = true
                    });
            };


            PictureBox pic = new PictureBox();
            pic.Dock = DockStyle.Right;
            pic.Width = 300;
            pic.SizeMode = PictureBoxSizeMode.Zoom;
            if (biz.Images != null && biz.Images.Count > 0)
            {
                try { pic.LoadAsync(biz.Images[0]); } catch { }
            }


            textPanel.Controls.Add(lblName);
            textPanel.Controls.Add(lblRating);
            textPanel.Controls.Add(lblCategory);
            textPanel.Controls.Add(btnWebsite);

            card.Controls.Add(textPanel);
            card.Controls.Add(pic);

            return card;
        }

        private async Task Api(string citystate, string food)
        {
            string url = $"https://yelp-business-reviews.p.rapidapi.com/search?location={citystate}&query={food}&limit=10";

            using (HttpClient client = new HttpClient())
            {
                client.DefaultRequestHeaders.Add("X-RapidAPI-Key", "3f063b706fmsh757cc59f38264b4p14be39jsned4f81524c86");
                client.DefaultRequestHeaders.Add("X-RapidAPI-Host", "yelp-business-reviews.p.rapidapi.com");

                try
                {
                    var response = await client.GetAsync(url);
                    var body = await response.Content.ReadAsStringAsync();


                    if (!response.IsSuccessStatusCode)
                    {
                        MessageBox.Show($"API Error: {response.StatusCode}");
                        return;
                    }

                    var apiResponse = JsonConvert.DeserializeObject<info>(body);

                    restaurantReviewFPanel.Controls.Clear();

                    foreach (var biz in apiResponse.Results)
                    {
                        var card = CreateReviewCard(biz);
                        restaurantReviewFPanel.Controls.Add(card);
                    }



                    return;
                }


                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                    return;
                }
            }
        }
        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void foodTypeLabel_Click(object sender, EventArgs e)
        {

        }

        private void citystateTB_TextChanged(object sender, EventArgs e)
        {

        }

        private async void findButton_Click(object sender, EventArgs e)
        {
            try
            {
                string food = foodTypeTB.Text?.Trim() ?? string.Empty;

                // Get public IP asynchronously
                string ip = await GetPublicIPAddressAsync();
                if (string.IsNullOrEmpty(ip))
                {
                    MessageBox.Show("Could not determine public IP address.");
                    return;
                }

                // Resolve location asynchronously
                var loc = await GetLocationFromIPAsync(ip);
                string citystate = loc?.Item1 ?? cityState;
                if (string.IsNullOrWhiteSpace(citystate))
                {
                    MessageBox.Show("Could not determine location for IP address.");
                    return;
                }

                await Api(citystate, food);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Unexpected error: {ex.Message}");
            }
        }
    }
}