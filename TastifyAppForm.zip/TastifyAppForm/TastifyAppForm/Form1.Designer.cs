﻿namespace TastifyAppForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.logoPicBox = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.logoLabel = new System.Windows.Forms.Label();
            this.foodTypeLabel = new System.Windows.Forms.Label();
            this.foodTypeTB = new System.Windows.Forms.TextBox();
            this.findButton = new System.Windows.Forms.Button();
            this.restaurantReviewFPanel = new System.Windows.Forms.FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // logoPicBox
            // 
            this.logoPicBox.BackColor = System.Drawing.Color.Red;
            this.logoPicBox.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.logoPicBox.Image = ((System.Drawing.Image)(resources.GetObject("logoPicBox.Image")));
            this.logoPicBox.Location = new System.Drawing.Point(8, 1);
            this.logoPicBox.Margin = new System.Windows.Forms.Padding(2);
            this.logoPicBox.Name = "logoPicBox";
            this.logoPicBox.Size = new System.Drawing.Size(49, 45);
            this.logoPicBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.logoPicBox.TabIndex = 0;
            this.logoPicBox.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Red;
            this.pictureBox1.Location = new System.Drawing.Point(-2, -1);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(857, 55);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // logoLabel
            // 
            this.logoLabel.AutoSize = true;
            this.logoLabel.BackColor = System.Drawing.Color.Red;
            this.logoLabel.Font = new System.Drawing.Font("MV Boli", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.logoLabel.ForeColor = System.Drawing.Color.Gold;
            this.logoLabel.Location = new System.Drawing.Point(53, 8);
            this.logoLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.logoLabel.Name = "logoLabel";
            this.logoLabel.Size = new System.Drawing.Size(132, 39);
            this.logoLabel.TabIndex = 2;
            this.logoLabel.Text = "Tastify!!";
            this.logoLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.logoLabel.Click += new System.EventHandler(this.logoLabel_Click);
            // 
            // foodTypeLabel
            // 
            this.foodTypeLabel.AutoSize = true;
            this.foodTypeLabel.Font = new System.Drawing.Font("Sitka Heading", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodTypeLabel.Location = new System.Drawing.Point(21, 77);
            this.foodTypeLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.foodTypeLabel.Name = "foodTypeLabel";
            this.foodTypeLabel.Size = new System.Drawing.Size(360, 35);
            this.foodTypeLabel.TabIndex = 3;
            this.foodTypeLabel.Text = "Please Enter your Cravings/Name:";
            this.foodTypeLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.foodTypeLabel.Click += new System.EventHandler(this.foodTypeLabel_Click);
            // 
            // foodTypeTB
            // 
            this.foodTypeTB.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.foodTypeTB.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.foodTypeTB.Location = new System.Drawing.Point(386, 80);
            this.foodTypeTB.Name = "foodTypeTB";
            this.foodTypeTB.Size = new System.Drawing.Size(175, 35);
            this.foodTypeTB.TabIndex = 6;
            this.foodTypeTB.TextChanged += new System.EventHandler(this.citystateTB_TextChanged);
            // 
            // findButton
            // 
            this.findButton.Font = new System.Drawing.Font("Sitka Heading", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.findButton.Location = new System.Drawing.Point(583, 70);
            this.findButton.Name = "findButton";
            this.findButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.findButton.Size = new System.Drawing.Size(115, 57);
            this.findButton.TabIndex = 7;
            this.findButton.Text = "Find Restaurants!";
            this.findButton.UseVisualStyleBackColor = true;
            this.findButton.Click += new System.EventHandler(this.findButton_Click);
            // 
            // restaurantReviewFPanel
            // 
            this.restaurantReviewFPanel.AutoScroll = true;
            this.restaurantReviewFPanel.Location = new System.Drawing.Point(26, 145);
            this.restaurantReviewFPanel.Name = "restaurantReviewFPanel";
            this.restaurantReviewFPanel.Size = new System.Drawing.Size(672, 218);
            this.restaurantReviewFPanel.TabIndex = 8;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(731, 392);
            this.Controls.Add(this.restaurantReviewFPanel);
            this.Controls.Add(this.findButton);
            this.Controls.Add(this.foodTypeTB);
            this.Controls.Add(this.foodTypeLabel);
            this.Controls.Add(this.logoLabel);
            this.Controls.Add(this.logoPicBox);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Form1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.logoPicBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox logoPicBox;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label logoLabel;
        private System.Windows.Forms.Label foodTypeLabel;
        private System.Windows.Forms.TextBox foodTypeTB;
        private System.Windows.Forms.Button findButton;
        private System.Windows.Forms.FlowLayoutPanel restaurantReviewFPanel;
    }
}

